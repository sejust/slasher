package constant

var (
	Version   = "unknown version"
	BuildTime = "unknown time"
)
