#!/usr/bin/env python2.6
# coding: utf-8
"""
Author : Slasher
"""

__version__ = '1.0.0'

import os
import sys
import time
import random


SPADE, HEART, DIAMOND, CLUD = '♠', '♥', '♦', '♣'
S, H, D, C = u'\u2660', u'\u2665', u'\u2666', u'\u2663'
SUIT = ( ( S, SPADE ), ( H, HEART ), ( D, DIAMOND ), ( C, CLUD ) )

JOKERBLACK, JOKERRED = u'JB', u'JR'
JOKER_B, JOKER_R = ( JOKERBLACK, 15 ), ( JOKERRED, 16 )

ANY = u'NN'
ANYCARD = ( ANY, 17 )

BASENUMS = tuple( [ n for n in range( 1, 14 ) ] )
BASECARDS = tuple( [ ( s, n ) for s, detail in SUIT for n in BASENUMS ] )


def format_card( cards, color = True ):

    if color and os.name != 'posix':
        color == False

    def _xstr( n ):

        numtochar = { 1  : 'A',
                      11 : 'J',
                      12 : 'Q',
                      13 : 'K',
                      14 : 'A',
                      15 : '',
                      16 : '',
                      17 : '' }

        n = int( n )
        if 2 <= n <= 10:
            return str( n )
        else:
            return numtochar[ n ]

    cs = []
    for s, n in cards:
        card = s.encode( 'utf8' ) + _xstr( n )
        if color and s in ( H, D, JOKERRED ):
            card = red( card )
        cs += [ card ]

    return cs

def red( s ):

    return "\033[31m%s\033[0m" % ( s )


class PokerError( Exception ): pass
class NotEnoughCard( PokerError ): pass


class Poker( object ):

    def __init__( self, number = 52 ):

        self.number = number
        self.createcards()

    def createcards( self ):

        self.usedcards = []

        if self.number == 40:
            ns = [ n for n in range( 1, 11 ) ]
            self.cards = [ ( s, n ) for s, detail in SUIT for n in ns ]

        elif self.number == 52:
            self.cards = list( BASECARDS )

        elif self.number == 54:
            self.cards = list( BASECARDS ) + [ JOKER_B, JOKER_R ]

        elif self.number == 55:
            self.cards = list( BASECARDS ) + [ JOKER_B, JOKER_R, ANYCARD ]

        else:
            self.cards = []


    def shuffle( self, seed = None ):

        seed = seed or time.time()
        random.seed( seed )

        random.shuffle( self.cards )

    def cut( self, index = 0 ):

        if index <= 0 and index > len( self.cards ) :
            return

        self.cards = self.cards[ index : ] + self.cards[ : index ]

    def pop( self, count = 1 ):

        if count > len( self.cards ):
            raise NotEnoughCard, 'the cards is not enough %d, remain %d' % \
                                        ( count, len( self.cards ), )

        popcards = self.cards[ : count ]
        self.cards = self.cards[ count : ]

        self.usedcards += popcards[ : ]

        return popcards


if __name__ == '__main__':

    poker = Poker( number = 52 )
    print ' '.join( format_card( poker.cards ) )

    poker.shuffle()
    print ' '.join( format_card( poker.cards ) )

    poker.cut( 4 )
    print ' '.join( format_card( poker.cards ) )

    print ' '.join( format_card( poker.pop( 2 ) ) )
    while True:
        try:
            y = raw_input( 'another one card: [y/n]' )
            if y.lower() == 'y':
                print ' '.join( format_card( poker.pop( 5 ) ) )
        except KeyboardInterrupt:
            print
            break

    print ' '.join( format_card( poker.cards ) )
    print ' '.join( format_card( poker.usedcards ) )


