#!/usr/bin/env python2.6
# coding: utf-8
"""
Author : Slasher
"""

__version__ = '1.0.0'


import blackjackbase


class BlackeJackError( blackjackbase.BlackeJackBaseError ): pass


class BlackeJack( blackjackbase.BlackeJackBase ):

    def __init__( self, playernames ):

        super( BlackeJack, self ).__init__( playernames, 10 )

    def balance( self ):

        for p in self.players:
            if self.compare( p ):
                if self.istrebleseven( p.cards ):
                    self.reallocpake( p, 10 * self.pake )
                elif self.istreble( p.cards ):
                    self.reallocpake( p, 5 * self.pake )
                elif self.isfivedragon( p.cards ):
                    self.reallocpake( p, 3 * self.pake )
                elif self.isdoubleace( p.cards ):
                    self.reallocpake( p, 3 * self.pake )
                elif self.isjack( p.cards ):
                    self.reallocpake( p, 2 * self.pake )
                else:
                    self.reallocpake( p, self.pake )


if __name__ == '__main__':

    bj = BlackeJack( [ 'jack', 'sam', 'jan', 'kate', 'slasher' ] )
    print [ p.name for p in bj.players ]



