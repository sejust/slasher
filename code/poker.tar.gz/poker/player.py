#!/usr/bin/env python2.6
# coding: utf-8
"""
Author : Slasher
"""

__version__ = '1.0.0'


import types

class PlayerError( Exception ): pass
class NoSuchCards( PlayerError ): pass


class Player( object ):

    def __init__( self, name ):

        self.name = name
        self.cards = []
        self.pake = 0

    def hit( self, card ):

        if type( card ) == type( [] ):
            self.cards += card
        else:
            self.cards.append( card )

    def pop( self, cards ):

        cards = cards if type( cards ) == type( [] ) else [ cards ]

        errorcards = list( set( cards ) - set( self.cards ) )

        if len( errorcards ) != 0:
            raise NoSuchCards, errorcards

        for card in cards:
            self.cards.remove( card )

        return cards

    def stand( self ):

        pass

