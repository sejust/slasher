#!/usr/bin/env python2.6
# coding: utf-8
"""
Author : Slasher
"""

__version__ = '1.0.0'


import poker
import player


BASEPAKE = 10


class BlackeJackBaseError( Exception ): pass
class UnknownPlayer( BlackeJackBaseError ): pass


class BlackeJackBase( poker.Poker ):

    def __init__( self, playernames = None, pake = None ):

        super( BlackeJackBase, self ).__init__( 52 )

        self.pake = pake or BASEPAKE

        playernames = playernames or \
                [ 'player' + str( i ) for i in range( 1, 6 ) ]
        if len( playernames ) < 2:
            raise BlackeJackBaseError, 'Player must be more than 2, now is %d' % \
                                            ( len( playernames ), )

        self.players = [ player.Player( name ) for name in playernames ]
        self.banker = self.players[ -1 ]
        self.players = self.players[ : -1 ]

        self.shuffle()

        self.initcards = False
        self._initcards()

    def _initcards( self ):

        if self.initcards:
            return

        for i in range( 0, 2 ):
            for p in self.players + [ self.banker ]:
                p.hit( self.pop( 1 ) )

        self.initcards = True

    def isplayeringame( self, p ):

        if p not in self.players + [ self.banker ]:
            raise UnknownPlayer, 'Named %s' % ( p.name )

    def isjack( self, cards ):

        if len( cards ) != 2:
            return False

        points = self.count_cards( cards )

        return True if 21 in points else False

    def isdoubleace( self, cards ):

        if len( cards ) != 2:
            return False

        points = self.count_cards( cards )

        return True if 2 in points else False

    def isfivedragon( self, cards ):

        if len( cards ) != 5:
            return False

        points = self.count_cards( cards )

        return True if min( points ) <= 21 else False

    def istreble( self, cards ):

        if len( cards ) != 3:
            return False

        cards = [ c[ 1 ] for c in cards ]

        return len( set( cards ) ) == 1

    def istrebleseven( self, cards ):

        if len( cards ) != 3:
            return False

        cards = [ c[ 1 ] for c in cards ]

        return cards == [ 7 ] * 3

    def count_cards( self, cards ):

        points = []

        cards = [ c[ 1 ] if c[ 1 ] < 11 else 10 for c in cards ]

        if sum( cards ) <= 2:
            points += [ sum( cards ) ]
            return points

        minsum = sum( cards )

        if minsum >= 21:
            points += [ minsum ]
            return points

        numace = cards.count( 1 )

        points = [ minsum + 10 * i  for i in range( 0, numace + 1 ) ]
        points = [ n for n in points if n <= 21 ]

        return points

    def hit( self, p ):

        self.isplayeringame( p )

        player.hit( self.pop( 1 ) )

    def compare( self, p ):

        self.isplayeringame( p )

        b_point = self.count_cards( self.banker.cards )
        p_point = self.count_cards( p.cards )

        if max( p_point ) > max( b_point ):
            return True
        elif max( p_point ) < max( b_point ):
            return False
        else:
            if len( player.cards ) < len( self.banker.cards ):
                return True
            else:
                return False

    def reallocpake( self, p, pake ):

        self.isplayeringame( p )

        p.pake += pake
        self.banker.pake -= pake

