
PATH = { 'log_dir' : '/var/log/' }

PIDFILE = '/var/run/test.pid'
