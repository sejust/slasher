
import time

import conf
import genlog

logger = genlog.logger


def run():

    i = 1
    while True:

        try:

            if i % 5 == 0 :
                raise Exception, 'some error'

            logger.info( 'loop %d: just for test' % ( i ) )
            time.sleep( 1 )

        except Exception, e:
            logger.error( 'loop %d: just for test error' % ( i ) )
            logger.exception( repr( e ) )

        i += 1


if __name__ == '__main__':

    import daemonize
    daemonize.standard_daemonize( run, conf.PIDFILE )
